namespace loops {
void printSum(int count);
void readTilZero();
void convertNokEur();
void multTable();
}