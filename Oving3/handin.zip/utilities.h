#pragma once

namespace utilities {
double get_random_number();
double randomWithLimits(double lb, double ub);
}