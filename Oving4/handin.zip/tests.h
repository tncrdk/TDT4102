#pragma once

namespace tests {
void testCallByValue();
void testCallByRef();
void testStudentStruct();
void testString();
}