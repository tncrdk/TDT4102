/** main.cpp

   This file is part of the handout for the TDT4102 spring 2022 exam.

   This file contains the main function that launches the application.

   You do not need to change or understand this file in
   order to solve the assignment.

**/

#include "application.h"
int main()
{

  Application app;
  app.main_loop();
  return 0;
}

