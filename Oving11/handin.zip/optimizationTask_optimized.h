#pragma once

void optimizationTask_optimized();
void optimizationTask_optimized_array();