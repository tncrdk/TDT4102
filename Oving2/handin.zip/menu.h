namespace menu {
int add(int a, int b);
void inputAndPrintInteger();
void inputIntegersAndPrintProduct();
int inputInteger();
bool isOdd(int value);
double inputDouble();
} // namespace menu