#pragma once
#include "std_lib_facilities.h"


enum class Location {
    Realfag,
    Stripa,
    Kjelhuset,
    Elektro
};

enum class Weekday {
    Monday = 0,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday,
    Sunday
};