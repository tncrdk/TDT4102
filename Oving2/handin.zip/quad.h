namespace quad {
double printRealRoots(double a, double b, double c);
double discriminant(double a, double b, double c);
void solveQuadratic();
}