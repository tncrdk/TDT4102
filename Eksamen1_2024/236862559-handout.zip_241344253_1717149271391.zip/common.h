#pragma once
#include "AnimationWindow.h"


#include <iostream>

// using Point = TDT4102::Point;
constexpr char IMAGE_DIR[] = "./images/";

// Card overlap in pixels
const int CARD_OVERLAP = 15;




